### How to contribute

* [fork this project](https://github.com/gitpython-developers/GitPython/fork) on GitHub
* For setting up the environment to run the self tests, look at `.travis.yml`.
* Add yourself to AUTHORS and write your patch. **Write a test that fails unless your patch is present.**
* Initiate a pull request

