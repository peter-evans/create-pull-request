If you need to mark a function, a class or a method as deprecated, you can use the @deprecated decorator.
This documentation explains how to install and use the Deprecated Library.
It includes a detailed tutorial and simple use cases.
You will also have all the keys to contribute to the source code development.

Why should you pay for this documentation? This a way to donate to the Deprecated Library project.
Your gratitude and financial help will be motivating to continue the project’s development.
