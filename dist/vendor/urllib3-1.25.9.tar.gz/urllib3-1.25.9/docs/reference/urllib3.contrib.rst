urllib3.contrib package
=======================

These modules implement various extra features, that may not be ready for
prime time or that require optional third-party dependencies.

urllib3.contrib.appengine module
--------------------------------

.. automodule:: urllib3.contrib.appengine
    :members:
    :undoc-members:
    :show-inheritance:

urllib3.contrib.ntlmpool module
-------------------------------

.. automodule:: urllib3.contrib.ntlmpool
    :members:
    :undoc-members:
    :show-inheritance:

urllib3.contrib.pyopenssl module
--------------------------------

.. automodule:: urllib3.contrib.pyopenssl
    :members:
    :undoc-members:
    :show-inheritance:

urllib3.contrib.socks module
----------------------------

.. automodule:: urllib3.contrib.socks
    :members:
    :undoc-members:
    :show-inheritance:
